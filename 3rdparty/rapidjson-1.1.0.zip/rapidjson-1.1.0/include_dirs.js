var path = require('path');
console.log(path.join(path.relative('.', __dirname), 'include'));
